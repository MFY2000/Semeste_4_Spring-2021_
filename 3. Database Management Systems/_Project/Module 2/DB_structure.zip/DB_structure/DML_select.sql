use [Portfolio_maker];


select * from admin_users;
select * from aboutus_setup;
select * from Theme;
select * from Theme_Customize;
select * from contact;
select * from personal_setup;
select * from Link_setup;
select * from ProjectDetail;
select * from Experience;
select * from skills;
select * from Licence;
select * from Owner_Setup;
select * from Request_Manager;