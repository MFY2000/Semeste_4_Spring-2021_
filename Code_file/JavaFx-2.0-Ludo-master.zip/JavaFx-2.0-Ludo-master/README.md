JavaFx-2.0-Ludo
===============

Ludo implementation in Javafx 2.0.3 platform